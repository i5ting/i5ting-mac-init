onmessage = function(event) {
	var data = event.data;
  	importScripts(data.url + 'highlight.pack.js');
  	var result = self.hljs.highlightAuto(data.html);
  	postMessage(result.value);
}
