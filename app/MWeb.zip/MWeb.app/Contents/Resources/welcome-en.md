# Welcome to MWeb

What is MWeb? MWeb is a Pro Markdown writing, note taking and static blog generator App. MWeb used Github Flavored Markdown syntax. Please check the MWeb official website: <http://www.mweb.im> introduction video, it will show you how to use MWeb. We also suggest that you check the MWeb official help document: <http://www.mweb.im/help.html>

## Things you should know

MWeb has two Mode, External Mode and Library Mode. 
In External Mode, you can edit classic text and markdown files from anywhere on your Mac. As an example, you can point MWeb to a folder on Dropbox. Library Mode design for note taking and static blog/website generator. For more info, please check the [MWeb official website](http://www.mweb.im) introduction video and help document.

## Help us to make MWeb better!

1. Tell your friends about MWeb.
2. Send Feedback: <coderforart+233@gmail.com>
3. Leave a review or at least a rating in Mac App Store.


